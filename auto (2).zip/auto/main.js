import { CarCard, DEFAULT_CAR_IMAGE } from './src/components/cars/CarCard.js';
import { INITIAL_CARS } from './src/data/cars.js';
import { formatMileage, formatPrice } from './src/utils/formatters.js';
import { escapeHtml, sanitizePhoneHref, sanitizeUrl } from './src/utils/sanitize.js';

const STORAGE_KEY_CARS = 'avto_market_cars_v8';
const STORAGE_KEY_FAVS = 'avto_market_favs_v1';
const STORAGE_KEY_THEME = 'avto_market_ios_theme_v1';
const STORAGE_KEY_CURRENCY = 'avto_market_currency_v1';

const BASE_CARS = INITIAL_CARS;

let cars = loadCars();
let favorites = loadFavorites();
let activeCategory = 'All';
let favoritesOnly = false;
let currentTheme = loadTheme();
let currentCurrency = loadCurrency();
let deferredPwaPrompt = null;

function loadTheme() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_THEME);
    if (saved === 'light' || saved === 'dark') return saved;
  } catch (_) {}
  return 'dark';
}

function setIosTheme(mode, animateThumb = true) {
  currentTheme = mode === 'light' ? 'light' : 'dark';
  const isDark = currentTheme === 'dark';

  document.documentElement.classList.toggle('dark', isDark);
  document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');

  const metaTheme = document.getElementById('meta-theme-color');
  if (metaTheme) metaTheme.setAttribute('content', isDark ? '#000000' : '#F2F2F7');

  const appleBar = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');
  if (appleBar) appleBar.setAttribute('content', isDark ? 'black-translucent' : 'default');

  const btnLight = document.getElementById('seg-light');
  const btnDark = document.getElementById('seg-dark');
  const thumb = document.getElementById('ios-segment-thumb');
  if (btnLight) btnLight.setAttribute('aria-pressed', String(!isDark));
  if (btnDark) btnDark.setAttribute('aria-pressed', String(isDark));

  if (thumb) {
    const targetX = isDark ? '100%' : '0%';
    if (animateThumb && window.gsap) {
      gsap.to(thumb, { x: targetX, duration: 0.36, ease: 'back.out(1.45)' });
    } else {
      thumb.style.transform = `translateX(${targetX})`;
    }
  }

  try {
    localStorage.setItem(STORAGE_KEY_THEME, currentTheme);
  } catch (_) {}
}

function loadCars() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CARS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (_) {}
  return [...INITIAL_CARS];
}

function saveCars() {
  try {
    localStorage.setItem(STORAGE_KEY_CARS, JSON.stringify(cars));
  } catch (_) {}
}

function loadFavorites() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_FAVS);
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return [];
}

function saveFavorites() {
  try {
    localStorage.setItem(STORAGE_KEY_FAVS, JSON.stringify(favorites));
  } catch (_) {}
  updateFavCounter();
}

function updateFavCounter() {
  const el = document.getElementById('fav-count');
  if (el) el.textContent = favorites.length;
}

function updateStats() {
  const totalEl = document.getElementById('stat-total-cars');
  if (totalEl) totalEl.textContent = cars.length;
}

function formatPrice(num) {
  return '$' + Number(num || 0).toLocaleString('en-US');
}

function formatMileage(km) {
  return Number(km || 0).toLocaleString('en-US') + ' km';
}

function selectCategory(category) {
  activeCategory = category;
  document.querySelectorAll('.cat-tab').forEach((btn) => {
    btn.classList.toggle('is-active', btn.dataset.category === category);
  });
  applyFilters();
}

function toggleFavoritesOnly() {
  favoritesOnly = !favoritesOnly;
  const btn = document.getElementById('btn-favorites-filter');
  if (btn) btn.classList.toggle('is-active', favoritesOnly);
  applyFilters();
}

function resetAllFilters() {
  activeCategory = 'All';
  favoritesOnly = false;
  const searchEl = document.getElementById('search-input');
  const fuelEl = document.getElementById('fuel-filter');
  const sortEl = document.getElementById('sort-filter');
  const favBtn = document.getElementById('btn-favorites-filter');

  if (searchEl) searchEl.value = '';
  if (fuelEl) fuelEl.value = 'all';
  if (sortEl) sortEl.value = 'featured';
  if (favBtn) favBtn.classList.remove('is-active');

  document.querySelectorAll('.cat-tab').forEach((btn) => {
    btn.classList.toggle('is-active', btn.dataset.category === 'All');
  });
  applyFilters();
}

function applyFilters() {
  const query = (document.getElementById('search-input')?.value || '').trim().toLowerCase();
  const fuel = document.getElementById('fuel-filter')?.value || 'all';
  const sort = document.getElementById('sort-filter')?.value || 'featured';

  const list = cars.filter((car) => {
    const matchesCat = activeCategory === 'All' || car.category === activeCategory;
    const matchesFuel = fuel === 'all' || car.fuel === fuel;
    const matchesFav = !favoritesOnly || favorites.includes(car.id);
    const matchesQuery =
      !query ||
      String(car.brand || '').toLowerCase().includes(query) ||
      String(car.model || '').toLowerCase().includes(query) ||
      String(car.city || '').toLowerCase().includes(query) ||
      String(car.category || '').toLowerCase().includes(query) ||
      String(car.year || '').includes(query);

    return matchesCat && matchesFuel && matchesFav && matchesQuery;
  });

  if (sort === 'price-asc') list.sort((a, b) => a.price - b.price);
  else if (sort === 'price-desc') list.sort((a, b) => b.price - a.price);
  else if (sort === 'year-desc') list.sort((a, b) => b.year - a.year);
  else if (sort === 'mileage-asc') list.sort((a, b) => a.mileage - b.mileage);
  else list.sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)));

  renderCars(list);
}

function renderCars(list) {
  const grid = document.getElementById('cars-grid');
  const emptyState = document.getElementById('empty-state');
  const countEl = document.getElementById('results-count');

  if (countEl) {
    countEl.textContent = `Showing ${list.length} ${list.length === 1 ? 'vehicle' : 'vehicles'}`;
  }

  if (!grid || !emptyState) return;

  if (!list.length) {
    grid.innerHTML = '';
    emptyState.classList.remove('hidden');
    return;
  }

  emptyState.classList.add('hidden');

  grid.innerHTML = list
    .map((car) =>
      CarCard(car, {
        isFavorite: favorites.includes(car.id),
        currency: currentCurrency,
        showSecondaryPrice: true
      })
    )
    .join('');

  if (window.gsap) {
    gsap.fromTo(
      '.car-card',
      { opacity: 0, y: 20, scale: 0.98 },
      {
        opacity: 1,
        y: 0,
        scale: 1,
        duration: 0.45,
        stagger: { amount: 0.28, from: 'start' },
        ease: 'power3.out',
        clearProps: 'transform'
      }
    );
  }
}

function toggleFavorite(id) {
  const idx = favorites.indexOf(id);
  if (idx === -1) {
    favorites.push(id);
    showToast('Saved to Favorites', 'success');
  } else {
    favorites.splice(idx, 1);
    showToast('Removed from Favorites', 'info');
  }
  saveFavorites();
  applyFilters();
}

function copyPhone(phone) {
  if (!phone) return;
  if (navigator.clipboard?.writeText) {
    navigator.clipboard.writeText(phone).catch(() => {});
  }
  showToast(`Copied ${phone}`, 'success');
}

function openCarDetails(id) {
  const car = cars.find((c) => c.id === id);
  if (!car) return;

  const content = document.getElementById('car-details-content');
  if (!content) return;

  const title = `${escapeHtml(car.brand)} ${escapeHtml(car.model)}`.trim();
  const imageUrl = escapeHtml(sanitizeUrl(car.image, DEFAULT_CAR_IMAGE));
  const phone = escapeHtml(car.phone);
  const phoneHref = escapeHtml(sanitizePhoneHref(car.phone));
  const formattedPrice = escapeHtml(
    formatPrice(car.price, {
      currency: currentCurrency,
      convertFromUsd: currentCurrency === 'UZS'
    })
  );
  const formattedMileage = escapeHtml(formatMileage(car.mileage));

  content.innerHTML = `
    <div class="relative h-60 sm:h-72 w-full">
      <img src="${imageUrl}" alt="${title}" class="w-full h-full object-cover" />
      <div class="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-black/25"></div>
      <button type="button" id="btn-close-details" class="btn btn-circle btn-sm bg-black/60 text-white border-0 absolute top-4 right-4">✕</button>
      <div class="absolute bottom-4 left-6 right-6 flex items-end justify-between gap-4 text-white">
        <div>
          <span class="badge badge-primary badge-sm font-bold">${escapeHtml(car.category)} • ${escapeHtml(car.year)}</span>
          <h3 class="text-2xl font-extrabold mt-1">${title}</h3>
        </div>
        <div class="text-xl sm:text-2xl font-extrabold text-info tabular-nums">${formattedPrice}</div>
      </div>
    </div>
    <div class="p-6 space-y-5">
      <p class="text-sm opacity-75 leading-relaxed">${escapeHtml(car.description)}</p>
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
        <div class="ios-inset-box p-3"><div class="text-[11px] opacity-60">Mileage</div><div class="font-bold text-xs sm:text-sm mt-0.5 tabular-nums">${formattedMileage}</div></div>
        <div class="ios-inset-box p-3"><div class="text-[11px] opacity-60">Fuel</div><div class="font-bold text-xs sm:text-sm mt-0.5">${escapeHtml(car.fuel)}</div></div>
        <div class="ios-inset-box p-3"><div class="text-[11px] opacity-60">Transmission</div><div class="font-bold text-xs sm:text-sm mt-0.5 truncate">${escapeHtml(car.transmission)}</div></div>
        <div class="ios-inset-box p-3"><div class="text-[11px] opacity-60">City</div><div class="font-bold text-xs sm:text-sm mt-0.5">${escapeHtml(car.city)}</div></div>
      </div>
      <div class="ios-inset-box p-3.5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div class="text-[11px] opacity-60">Seller: <strong>${escapeHtml(car.seller)}</strong></div>
          ${phoneHref
            ? `<a href="${phoneHref}" class="text-sm font-extrabold text-success hover:underline tabular-nums">${phone}</a>`
            : `<span class="text-sm font-extrabold tabular-nums">${phone}</span>`}
        </div>
        <div class="flex items-center gap-2">
          <button type="button" id="btn-details-copy-phone" data-phone="${phone}" class="btn btn-ghost btn-xs rounded-full">Copy Number</button>
          ${phoneHref ? `<a href="${phoneHref}" class="btn btn-primary btn-xs rounded-full">Call Seller</a>` : ''}
        </div>
      </div>
      <form id="test-drive-form" class="space-y-3 pt-2 border-t border-base-300">
        <h4 class="font-bold text-sm">Book a Test Drive</h4>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <input type="text" required placeholder="Your Full Name" class="input input-bordered w-full input-sm" />
          <input type="tel" required placeholder="+998 88 202 5252" class="input input-bordered w-full input-sm" />
        </div>
        <button type="submit" class="btn btn-primary w-full btn-sm">Confirm Test Drive Request</button>
      </form>
    </div>
  `;

  document.getElementById('btn-close-details')?.addEventListener('click', () => {
    document.getElementById('car-details-modal')?.close();
  });

  document.getElementById('btn-details-copy-phone')?.addEventListener('click', () => {
    copyPhone(car.phone);
  });

  document.getElementById('test-drive-form')?.addEventListener('submit', (event) => {
    event.preventDefault();
    document.getElementById('car-details-modal')?.close();
    showToast(`Test drive requested for ${car.brand} ${car.model}!`, 'success');
  });

  const dialog = document.getElementById('car-details-modal');
  dialog?.showModal();
  if (window.gsap) {
    gsap.fromTo(
      '#details-modal-box',
      { scale: 0.92, y: 18, opacity: 0 },
      { scale: 1, y: 0, opacity: 1, duration: 0.34, ease: 'back.out(1.35)' }
    );
  }
}

function openSellModal() {
  const dialog = document.getElementById('sell-car-modal');
  dialog?.showModal();
  if (window.gsap) {
    gsap.fromTo(
      '#sell-modal-box',
      { scale: 0.92, y: 18, opacity: 0 },
      { scale: 1, y: 0, opacity: 1, duration: 0.34, ease: 'back.out(1.35)' }
    );
  }
}

function closeSellModal() {
  document.getElementById('sell-car-modal').close();
}

function setPresetImage(url) {
  const input = document.getElementById('new-image');
  if (input) input.value = url;
}

function handleAddCar(event) {
  event.preventDefault();
  const brand = document.getElementById('new-brand')?.value.trim() || '';
  const model = document.getElementById('new-model')?.value.trim() || '';
  const year = Number(document.getElementById('new-year')?.value) || 2025;
  const price = Number(document.getElementById('new-price')?.value) || 25000;
  const mileage = Number(document.getElementById('new-mileage')?.value) || 0;
  const category = document.getElementById('new-category')?.value || 'Sedan';
  const fuel = document.getElementById('new-fuel')?.value || 'Petrol';
  const city = document.getElementById('new-city')?.value.trim() || 'Tashkent';
  const transmission = document.getElementById('new-transmission')?.value.trim() || 'Automatic';
  const phone = document.getElementById('new-phone')?.value.trim() || '+998 88 202 5252';
  const rawImage = document.getElementById('new-image')?.value.trim() || '';
  const image = sanitizeUrl(rawImage, DEFAULT_CAR_IMAGE);
  const description =
    document.getElementById('new-description')?.value.trim() ||
    `${year} ${brand} ${model} listed on Avto Market.`;

  cars.unshift({
    id: 'car-' + Date.now(),
    brand,
    model,
    year,
    price,
    mileage,
    category,
    fuel,
    transmission,
    city,
    condition: mileage < 500 ? 'New' : 'Used',
    featured: true,
    phone,
    seller: 'Private Seller',
    image,
    description
  });

  saveCars();
  updateStats();
  closeSellModal();
  document.getElementById('sell-car-form').reset();
  document.getElementById('new-phone').value = '+998 88 202 5252';
  document.getElementById('new-image').value = INITIAL_CARS[0].image;
  resetAllFilters();
  showToast(`${brand} ${model} published!`, 'success');
}

function resetDemoData() {
  cars = [...INITIAL_CARS];
  favorites = [];
  saveCars();
  saveFavorites();
  updateStats();
  resetAllFilters();
  showToast('Catalog reset to 20 vehicles', 'info');
}

function initPwa() {
  const swBadge = document.getElementById('sw-status-badge');
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    navigator.serviceWorker
      .register('./sw.js')
      .then(() => {
        if (swBadge) {
          swBadge.textContent = 'Active & Ready';
          swBadge.className = 'px-2.5 py-1 rounded-full text-xs font-bold bg-[#34C759]/15 text-[#34C759] dark:text-[#30D158]';
        }
      })
      .catch(() => {
        if (swBadge) swBadge.textContent = 'Preview Mode';
      });
  } else if (swBadge) {
    swBadge.textContent = 'Ready (HTTPS/Localhost)';
  }

  const modeEl = document.getElementById('pwa-display-mode');
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
  if (modeEl) modeEl.textContent = isStandalone ? 'standalone (installed)' : 'browser tab';

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPwaPrompt = e;
    document.getElementById('btn-install-pwa')?.classList.remove('hidden');
  });
}

function openPwaModal() {
  const dialog = document.getElementById('pwa-modal');
  dialog.showModal();
  if (window.gsap) gsap.fromTo('#pwa-modal-box', { scale: 0.92, y: 18, opacity: 0 }, { scale: 1, y: 0, opacity: 1, duration: 0.34, ease: 'back.out(1.35)' });
}

function closePwaModal() {
  document.getElementById('pwa-modal').close();
}

async function triggerPwaInstall() {
  if (!deferredPwaPrompt) return;
  deferredPwaPrompt.prompt();
  await deferredPwaPrompt.userChoice;
  deferredPwaPrompt = null;
  document.getElementById('btn-install-pwa')?.classList.add('hidden');
  closePwaModal();
}

function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const colorMap = {
    success: 'bg-[#34C759] text-black dark:bg-[#30D158] dark:text-black',
    info: 'bg-[#007AFF] text-white dark:bg-[#0A84FF] dark:text-white',
    error: 'bg-[#FF3B30] text-white dark:bg-[#FF453A] dark:text-white'
  };

  const toast = document.createElement('div');
  toast.className = `badge ${colorMap[type] || colorMap.info} badge-lg shadow-xl font-bold py-3 px-4`;
  toast.textContent = message;
  container.appendChild(toast);

  if (window.gsap) {
    gsap.fromTo(
      toast,
      { opacity: 0, y: 20, scale: 0.92 },
      { opacity: 1, y: 0, scale: 1, duration: 0.3, ease: 'back.out(1.4)' }
    );
    gsap.to(toast, {
      opacity: 0,
      y: -10,
      duration: 0.25,
      delay: 2.3,
      onComplete: () => toast.remove()
    });
  } else {
    setTimeout(() => toast.remove(), 2500);
  }
}

function bindEvents() {
  document.getElementById('seg-light')?.addEventListener('click', () => setIosTheme('light'));
  document.getElementById('seg-dark')?.addEventListener('click', () => setIosTheme('dark'));

  document.getElementById('btn-currency-usd')?.addEventListener('click', () => setCurrency('USD'));
  document.getElementById('btn-currency-uzs')?.addEventListener('click', () => setCurrency('UZS'));

  document.getElementById('btn-favorites-filter')?.addEventListener('click', toggleFavoritesOnly);
  document.getElementById('btn-open-sell')?.addEventListener('click', openSellModal);
  document.getElementById('btn-close-sell')?.addEventListener('click', closeSellModal);
  document.getElementById('sell-car-form')?.addEventListener('submit', handleAddCar);

  document.getElementById('btn-open-pwa')?.addEventListener('click', openPwaModal);
  document.getElementById('btn-close-pwa')?.addEventListener('click', closePwaModal);
  document.getElementById('btn-install-pwa')?.addEventListener('click', triggerPwaInstall);

  document.getElementById('btn-reset-demo')?.addEventListener('click', resetDemoData);
  document.getElementById('btn-reset-filters')?.addEventListener('click', resetAllFilters);
  document.getElementById('btn-empty-reset')?.addEventListener('click', resetAllFilters);

  document.querySelectorAll('.cat-tab').forEach((btn) => {
    btn.addEventListener('click', () => selectCategory(btn.dataset.category || 'All'));
  });

  document.getElementById('search-input')?.addEventListener('input', applyFilters);
  document.getElementById('fuel-filter')?.addEventListener('change', applyFilters);
  document.getElementById('sort-filter')?.addEventListener('change', applyFilters);

  document.getElementById('cars-grid')?.addEventListener('click', (event) => {
    const actionEl = event.target.closest('[data-action]');
    if (!actionEl) return;

    const action = actionEl.dataset.action;
    if (action === 'toggle-favorite') {
      event.stopPropagation();
      toggleFavorite(actionEl.dataset.carId);
    } else if (action === 'copy-phone') {
      event.stopPropagation();
      copyPhone(actionEl.dataset.phone);
    } else if (action === 'open-details') {
      openCarDetails(actionEl.dataset.carId);
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  setIosTheme(currentTheme, false);
  setCurrency(currentCurrency);
  updateFavCounter();
  updateStats();
  bindEvents();
  initPwa();

  if (window.gsap) {
    gsap.from('.hero-stagger', {
      opacity: 0,
      y: 22,
      duration: 0.65,
      stagger: 0.08,
      ease: 'power3.out',
      clearProps: 'transform'
    });
  }
});