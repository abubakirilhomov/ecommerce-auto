export const DEFAULT_USD_TO_UZS_RATE = 12800;

/**
 * Parses a numeric value and clamps invalid or negative values to 0.
 * @param {unknown} value
 * @returns {number}
 */
function toNonNegativeNumber(value) {
  if (value === null || value === undefined || value === '') return 0;
  const num = Number(value);
  if (!Number.isFinite(num) || num < 0) return 0;
  return num;
}

/**
 * Formats an integer with ASCII space thousands separators (e.g. `1 250 000`).
 * @param {number} value
 * @returns {string}
 */
function formatSpaceGroupedInteger(value) {
  return Math.round(value)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}

/**
 * Converts an amount in USD to UZS using the provided exchange rate.
 * @param {unknown} usdAmount
 * @param {number} [rate=DEFAULT_USD_TO_UZS_RATE]
 * @returns {number}
 */
export function convertUsdToUzs(usdAmount, rate = DEFAULT_USD_TO_UZS_RATE) {
  const safeUsd = toNonNegativeNumber(usdAmount);
  const safeRate = Number.isFinite(Number(rate)) && Number(rate) > 0
    ? Number(rate)
    : DEFAULT_USD_TO_UZS_RATE;

  return Math.round(safeUsd * safeRate);
}

/**
 * Formats a price in USD (e.g. `$345,000`).
 * @param {unknown} amount
 * @returns {string}
 */
export function formatUsdPrice(amount) {
  const safeAmount = toNonNegativeNumber(amount);
  const hasDecimals = !Number.isInteger(safeAmount);
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: hasDecimals ? 2 : 0
  }).format(safeAmount);
}

/**
 * Formats a price in UZS (e.g. `4 416 000 000 UZS`).
 * @param {unknown} amount
 * @param {{ suffix?: string, convertFromUsd?: boolean, rate?: number }} [options]
 * @returns {string}
 */
export function formatUzsPrice(amount, options = {}) {
  const {
    suffix = 'UZS',
    convertFromUsd = false,
    rate = DEFAULT_USD_TO_UZS_RATE
  } = options;

  const uzsAmount = convertFromUsd
    ? convertUsdToUzs(amount, rate)
    : toNonNegativeNumber(amount);

  return `${formatSpaceGroupedInteger(uzsAmount)} ${suffix}`.trim();
}

/**
 * Formats a price in either USD or UZS.
 * Accepts either `formatPrice(amount, 'UZS')` or `formatPrice(amount, { currency: 'UZS', convertFromUsd: true })`.
 * @param {unknown} amount
 * @param {'USD' | 'UZS' | { currency?: 'USD' | 'UZS', convertFromUsd?: boolean, rate?: number, suffix?: string }} [currencyOrOptions='USD']
 * @param {{ convertFromUsd?: boolean, rate?: number, suffix?: string }} [extraOptions={}]
 * @returns {string}
 */
export function formatPrice(amount, currencyOrOptions = 'USD', extraOptions = {}) {
  const options = typeof currencyOrOptions === 'string'
    ? { currency: currencyOrOptions, ...extraOptions }
    : { currency: 'USD', ...currencyOrOptions, ...extraOptions };

  const currency = String(options.currency || 'USD').toUpperCase();

  if (currency === 'UZS') {
    return formatUzsPrice(amount, options);
  }

  return formatUsdPrice(amount);
}

/**
 * Formats vehicle mileage with unit suffix (e.g. `24 500 km`).
 * @param {unknown} mileage
 * @param {string | { unit?: string }} [unitOrOptions='km']
 * @returns {string}
 */
export function formatMileage(mileage, unitOrOptions = 'km') {
  const unit = typeof unitOrOptions === 'string'
    ? unitOrOptions
    : (unitOrOptions?.unit ?? 'km');

  const safeMileage = toNonNegativeNumber(mileage);
  return `${formatSpaceGroupedInteger(safeMileage)} ${unit}`.trim();
}
