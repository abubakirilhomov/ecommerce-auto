/**
 * Escapes HTML special characters to prevent XSS when interpolating values into HTML strings.
 * @param {unknown} value
 * @returns {string}
 */
export function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Validates and sanitizes a URL, allowing only http(s) URLs or safe relative paths.
 * Returns `fallback` when the input is empty, malformed, or uses an unsafe protocol.
 * @param {unknown} url
 * @param {string} [fallback='']
 * @param {{ allowedProtocols?: string[] }} [options]
 * @returns {string}
 */
export function sanitizeUrl(url, fallback = '', options = {}) {
  if (typeof url !== 'string') return fallback;

  const trimmed = url.trim();
  if (!trimmed || /[\u0000-\u001F\u007F]/.test(trimmed)) {
    return fallback;
  }

  // Allow safe relative paths (but reject protocol-relative URLs like //evil.com)
  if (
    (trimmed.startsWith('/') && !trimmed.startsWith('//')) ||
    trimmed.startsWith('./') ||
    trimmed.startsWith('../')
  ) {
    return trimmed;
  }

  const allowedProtocols = options.allowedProtocols ?? ['http:', 'https:'];

  try {
    const parsed = new URL(trimmed);
    if (!allowedProtocols.includes(parsed.protocol)) {
      return fallback;
    }
    return parsed.href;
  } catch {
    return fallback;
  }
}

/**
 * Produces a safe `tel:` URI from a phone string, or an empty string if invalid.
 * @param {unknown} phone
 * @returns {string}
 */
export function sanitizePhoneHref(phone) {
  if (typeof phone !== 'string' && typeof phone !== 'number') return '';
  const raw = String(phone).trim();
  if (!raw) return '';

  const hasLeadingPlus = raw.startsWith('+');
  const digits = raw.replace(/\D/g, '');
  if (!digits) return '';

  return `tel:${hasLeadingPlus ? '+' : ''}${digits}`;
}
