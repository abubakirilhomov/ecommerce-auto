import { escapeHtml, sanitizePhoneHref, sanitizeUrl } from '../../utils/sanitize.js';
import {
  DEFAULT_USD_TO_UZS_RATE,
  formatMileage,
  formatPrice
} from '../../utils/formatters.js';

export const DEFAULT_CAR_IMAGE =
  'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=1200&q=80';

const FUEL_BADGE_MAP = {
  electric: 'badge-success',
  hybrid: 'badge-info',
  petrol: 'badge-warning',
  diesel: 'badge-accent'
};

/**
 * Returns the DaisyUI badge modifier class corresponding to the vehicle's fuel type.
 * @param {unknown} fuel
 * @returns {string}
 */
export function getFuelBadgeClass(fuel) {
  const key = String(fuel || '').trim().toLowerCase();
  return FUEL_BADGE_MAP[key] || 'badge-neutral';
}

/**
 * Renders an accessible, XSS-safe DaisyUI car listing card HTML string.
 * @param {Record<string, any>} car
 * @param {{
 *   isFavorite?: boolean,
 *   currency?: 'USD' | 'UZS',
 *   exchangeRate?: number,
 *   showSecondaryPrice?: boolean,
 *   mileageUnit?: string
 * }} [options]
 * @returns {string}
 */
export function CarCard(car, options = {}) {
  const {
    isFavorite = false,
    currency = 'USD',
    exchangeRate = DEFAULT_USD_TO_UZS_RATE,
    showSecondaryPrice = true,
    mileageUnit = 'km'
  } = options;

  const id = escapeHtml(car?.id ?? '');
  const brand = escapeHtml(car?.brand ?? '');
  const model = escapeHtml(car?.model ?? '');
  const title = `${brand} ${model}`.trim() || 'Vehicle';
  const year = escapeHtml(car?.year ?? '');
  const condition = escapeHtml(car?.condition ?? '');
  const city = escapeHtml(car?.city ?? '');
  const fuel = escapeHtml(car?.fuel ?? '');
  const category = escapeHtml(car?.category ?? '');
  const seller = escapeHtml(car?.seller ?? '');
  const transmission = escapeHtml(car?.transmission ?? '');
  const phone = escapeHtml(car?.phone ?? '');
  const phoneHref = sanitizePhoneHref(car?.phone ?? '');
  const imageUrl = sanitizeUrl(car?.image, DEFAULT_CAR_IMAGE);
  const fallbackImageUrl = escapeHtml(DEFAULT_CAR_IMAGE);

  const normalizedCurrency = String(currency).toUpperCase() === 'UZS' ? 'UZS' : 'USD';
  const primaryPrice = formatPrice(car?.price, {
    currency: normalizedCurrency,
    convertFromUsd: normalizedCurrency === 'UZS',
    rate: exchangeRate
  });

  const secondaryPrice = showSecondaryPrice
    ? formatPrice(car?.price, {
        currency: normalizedCurrency === 'USD' ? 'UZS' : 'USD',
        convertFromUsd: normalizedCurrency === 'USD',
        rate: exchangeRate
      })
    : '';

  const mileageText = formatMileage(car?.mileage, mileageUnit);
  const fuelBadgeClass = getFuelBadgeClass(car?.fuel);

  return `
    <article
      class="car-card card bg-base-100 border border-base-300 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden"
      data-car-id="${id}"
    >
      <figure class="relative h-52 w-full overflow-hidden bg-base-200">
        <img
          src="${escapeHtml(imageUrl)}"
          alt="${title}"
          loading="lazy"
          class="w-full h-full object-cover"
          onerror="this.onerror=null;this.src='${fallbackImageUrl}'"
        />
        <div class="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-black/25"></div>

        <div class="absolute top-3 left-3 flex items-center gap-1.5">
          ${year ? `<span class="badge badge-neutral badge-sm font-bold">${year}</span>` : ''}
          ${condition ? `<span class="badge badge-ghost badge-sm bg-base-100/90 text-base-content font-semibold">${condition}</span>` : ''}
        </div>

        <button
          type="button"
          data-action="toggle-favorite"
          data-car-id="${id}"
          aria-label="Save ${title}"
          aria-pressed="${isFavorite ? 'true' : 'false'}"
          class="btn btn-circle btn-sm bg-black/55 hover:bg-black/75 border-0 text-white absolute top-3 right-3"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="w-4 h-4 ${isFavorite ? 'text-error fill-error' : 'text-white'}"
            viewBox="0 0 24 24"
            fill="${isFavorite ? 'currentColor' : 'none'}"
            stroke="currentColor"
            stroke-width="2.2"
            aria-hidden="true"
          >
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
          </svg>
        </button>

        <div class="absolute bottom-2.5 left-3 right-3 flex items-center justify-between gap-2">
          ${city ? `<span class="badge badge-neutral badge-sm bg-black/60 border-0 text-white">${city}</span>` : '<span></span>'}
          ${fuel ? `<span class="badge ${fuelBadgeClass} badge-sm font-bold">${fuel}</span>` : ''}
        </div>
      </figure>

      <div class="card-body p-5 justify-between gap-4">
        <div class="space-y-2">
          <div class="flex items-center justify-between gap-2 text-xs font-semibold uppercase tracking-wider text-base-content/60">
            <span class="truncate">${category}</span>
            <span class="truncate">${seller}</span>
          </div>

          <h3 class="card-title text-lg leading-snug line-clamp-1">${title}</h3>

          <div>
            <p class="text-2xl font-extrabold text-primary tabular-nums">${escapeHtml(primaryPrice)}</p>
            ${secondaryPrice ? `<p class="text-xs font-medium text-base-content/60 tabular-nums">${escapeHtml(secondaryPrice)}</p>` : ''}
          </div>

          <div class="grid grid-cols-2 gap-2 text-xs text-base-content/75 pt-2 border-t border-base-300">
            <span class="tabular-nums">${escapeHtml(mileageText)}</span>
            <span class="truncate text-right">${transmission}</span>
          </div>

          ${phone ? `
            <div class="flex items-center justify-between gap-2 rounded-box bg-base-200 px-3 py-2">
              ${phoneHref
                ? `<a href="${escapeHtml(phoneHref)}" class="text-xs font-bold text-success hover:underline tabular-nums">${phone}</a>`
                : `<span class="text-xs font-bold tabular-nums">${phone}</span>`}
              <button
                type="button"
                data-action="copy-phone"
                data-phone="${phone}"
                class="btn btn-ghost btn-xs"
              >
                Copy
              </button>
            </div>
          ` : ''}
        </div>

        <div class="card-actions items-center gap-2 pt-1">
          <button
            type="button"
            data-action="open-details"
            data-car-id="${id}"
            class="btn btn-primary btn-sm flex-1"
          >
            Details &amp; Test Drive
          </button>
          ${phoneHref ? `
            <a
              href="${escapeHtml(phoneHref)}"
              class="btn btn-outline btn-success btn-sm shrink-0"
            >
              Call
            </a>
          ` : ''}
        </div>
      </div>
    </article>
  `.trim();
}

export default CarCard;
